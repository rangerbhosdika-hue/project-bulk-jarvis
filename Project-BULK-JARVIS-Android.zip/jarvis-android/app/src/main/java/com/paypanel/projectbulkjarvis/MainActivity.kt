package com.paypanel.projectbulkjarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var restarting = false
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var robot: TextView
    private lateinit var transcript: TextView
    private lateinit var toggle: Button

    private val restartTask = Runnable {
        restarting = false
        if (listening) startRecognition()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech service unavailable on this phone"
            toggle.isEnabled = false
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(5, 11, 22))
        }
        val title = TextView(this).apply {
            text = "PROJECT BULK  /  JARVIS"
            textSize = 20f
            setTextColor(Color.rgb(0, 229, 255))
            gravity = Gravity.CENTER
        }
        robot = TextView(this).apply {
            text = "◉"
            textSize = 112f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(0, 229, 255))
            visibility = View.GONE
            setPadding(0, 45, 0, 45)
        }
        status = TextView(this).apply {
            text = "Tap START LISTENING"
            textSize = 17f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 12)
        }
        transcript = TextView(this).apply {
            text = "Say “Jarvis” to show the robot\nSay “Bye Jarvis” to hide it"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        toggle = Button(this).apply {
            text = "START LISTENING"
            setOnClickListener { if (listening) stopListening() else requestMicAndStart() }
        }
        val hint = TextView(this).apply {
            text = "Voice works while this app is open. No chatbot or AI model is used."
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 26, 0, 0)
        }
        root.addView(title)
        root.addView(robot)
        root.addView(status)
        root.addView(transcript)
        root.addView(toggle)
        root.addView(hint)
        setContentView(root)
    }

    private fun requestMicAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
        } else {
            listening = true
            toggle.text = "STOP LISTENING"
            status.text = "Listening for “Jarvis”…"
            startRecognition()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            requestMicAndStart()
        } else if (requestCode == 41) {
            status.text = "Microphone permission is required"
        }
    }

    private fun startRecognition() {
        if (!listening || isFinishing) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "No Android speech recognition service found"
            listening = false
            toggle.text = "START LISTENING"
            return
        }
        try {
            if (recognizer == null) recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            status.text = "Mic start failed: " + e.javaClass.simpleName
            scheduleRestart()
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening for “Jarvis”…" }
        override fun onBeginningOfSpeech() { status.text = "Hearing you…" }
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { status.text = "Processing voice…" }
        override fun onError(error: Int) {
            if (listening) {
                status.text = "Listening… (speech service reconnecting)"
                scheduleRestart()
            }
        }
        override fun onResults(results: Bundle?) {
            handleSpeech(results)
            scheduleRestart()
        }
        override fun onPartialResults(partialResults: Bundle?) { handleSpeech(partialResults) }
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleSpeech(bundle: Bundle?) {
        val phrases = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        if (phrases.isEmpty()) return
        transcript.text = "Heard: " + phrases.joinToString(" / ")
        val normalized = phrases.joinToString(" ").lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\\\s+"), " ").trim()
        val wake = Regex("\\\\b(jarvis|jar wiz|jarviss)\\\\b")
        val sleep = Regex("\\\\b(bye|goodbye|hide|close|sleep)\\\\b.*\\\\b(jarvis|jar wiz|jarviss)\\\\b|\\\\b(jarvis|jar wiz|jarviss)\\\\b.*\\\\b(bye|goodbye|hide|close|sleep)\\\\b")
        if (wake.containsMatchIn(normalized)) {
            if (sleep.containsMatchIn(normalized)) {
                robot.visibility = View.GONE
                status.text = "JARVIS hidden"
            } else {
                robot.visibility = View.VISIBLE
                status.text = "JARVIS activated"
            }
        }
    }

    private fun scheduleRestart() {
        if (!listening || restarting) return
        restarting = true
        handler.removeCallbacks(restartTask)
        handler.postDelayed(restartTask, 650)
    }

    private fun stopListening() {
        listening = false
        restarting = false
        handler.removeCallbacks(restartTask)
        try { recognizer?.cancel() } catch (_: Exception) {}
        status.text = "Listening stopped"
        toggle.text = "START LISTENING"
    }

    override fun onPause() {
        super.onPause()
        if (listening) {
            listening = false
            handler.removeCallbacks(restartTask)
            try { recognizer?.cancel() } catch (_: Exception) {}
            toggle.text = "START LISTENING"
            status.text = "Paused — tap START LISTENING when app is open"
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }
}
