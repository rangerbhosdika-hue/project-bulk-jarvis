# Project BULK JARVIS — Android app

A native Android app with two voice commands:
- “Jarvis” → show the robot indicator.
- “Bye Jarvis” → hide the robot indicator.

No chatbot, LLM, paid API, or external AI model is included. It uses Android's installed speech-recognition service and microphone permission. Listening is foreground-only: it runs while this app is open, and pauses when the app leaves the foreground.

## Build the APK free using GitHub Actions (phone-only setup)

1. Download and extract this ZIP on your Android phone.
2. In Chrome, open https://github.com/new and create a repository named project-bulk-jarvis. Set it to Private or Public.
3. Open the new repository, choose Add file → Upload files, and upload the extracted project contents (the app folder, .github folder, and root Gradle files). Do not upload the ZIP as a single file.
4. Commit the files to the main branch.
5. Open the repository's Actions tab. If GitHub asks, enable Actions. Select Build Project BULK JARVIS APK and tap Run workflow (a push to main also starts a build).
6. When the run finishes successfully, open it, scroll to Artifacts, and download Project-BULK-JARVIS-debug-apk. Extract it and install app-debug.apk. Android may ask permission to install apps from Chrome/Files.
7. Open the app, allow microphone permission, and tap START LISTENING.

## Notes
- Requires a working Android speech recognition provider on the phone (for example, Google's speech service). This app does not bundle offline speech recognition.
- Internet may be required by the phone's speech provider.
- The app does not listen while minimized, screen-off, or closed.
- This is a debug APK for personal testing, not a Play Store release.
